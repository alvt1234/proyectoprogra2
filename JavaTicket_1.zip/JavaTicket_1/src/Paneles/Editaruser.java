
package Paneles;

import JavaTicket.UsuarioRegistrado;
import JavaTicket.controlarusuarios;
import javax.swing.JOptionPane;

/**
 *
 * @author villa
 */
public class Editaruser extends javax.swing.JPanel {
    private String nombre,users,contra,tipo;
    int edads,edad;
    public Editaruser() {
        initComponents();
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtuser = new javax.swing.JTextField();
        btaceptar = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtusername = new javax.swing.JTextField();
        txtedad = new javax.swing.JTextField();
        txttipouser = new javax.swing.JTextField();
        txtcontra = new javax.swing.JTextField();
        btbuscar = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        txtnombre = new javax.swing.JTextField();

        jPanel1.setBackground(new java.awt.Color(204, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        jLabel1.setText("Edad:");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 300, 140, 30));

        jLabel2.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        jLabel2.setText("Editar usuario");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 140, 30));

        txtuser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtuserActionPerformed(evt);
            }
        });
        jPanel1.add(txtuser, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 60, 220, 30));

        btaceptar.setBackground(new java.awt.Color(255, 204, 204));
        btaceptar.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        btaceptar.setText("Aceptar");
        btaceptar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btaceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btaceptarActionPerformed(evt);
            }
        });
        jPanel1.add(btaceptar, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 360, 120, 40));

        jLabel3.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        jLabel3.setText("Buscar Usuario:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 60, 140, 30));

        jLabel4.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        jLabel4.setText("Tipo de Usuario:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 150, 170, 30));

        jLabel5.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        jLabel5.setText("Username:");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 220, 160, 30));

        jLabel6.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        jLabel6.setText("Contraseña:");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 260, 150, 30));

        txtusername.setEnabled(false);
        jPanel1.add(txtusername, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 220, 230, 30));

        txtedad.setEnabled(false);
        jPanel1.add(txtedad, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 300, 120, 30));

        txttipouser.setEnabled(false);
        jPanel1.add(txttipouser, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 140, 230, 30));

        txtcontra.setEnabled(false);
        jPanel1.add(txtcontra, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 260, 230, 30));

        btbuscar.setBackground(new java.awt.Color(255, 204, 204));
        btbuscar.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        btbuscar.setText("Buscar");
        btbuscar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btbuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btbuscarActionPerformed(evt);
            }
        });
        jPanel1.add(btbuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 50, 120, 40));

        jLabel7.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        jLabel7.setText("Nombre completo:");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 180, 180, 30));

        txtnombre.setEnabled(false);
        jPanel1.add(txtnombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 180, 230, 30));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 751, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 510, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btaceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btaceptarActionPerformed
    if(txtcontra.getText().isEmpty() || txtedad.getText().isEmpty() || txtnombre.getText().isEmpty() || txtuser.getText().isEmpty() ){         
            JOptionPane.showMessageDialog(null, "Tiene que llenar todos los campos");
    }else{
     nombre=txtnombre.getText();
     users=txtusername.getText();
     contra=txtcontra.getText();
     tipo=txttipouser.getText();
     edads=Integer.parseInt(txtedad.getText());
      String usuario=txtuser.getText();
      UsuarioRegistrado aux = controlarusuarios.buscarUsuario(usuario);
     
     if(aux.getUsuarios().equals(usuario)){
         aux.setUsuarios(users);
         aux.setNombrecom(nombre);
         aux.setContraseña(contra);
         aux.setTipousuario(tipo);
         aux.setEdad(edad);
     JOptionPane.showMessageDialog(null, "Usuario editado correctamente");
         limpiarcasillas();
     }else
         JOptionPane.showMessageDialog(null, "Username no disponible.");
    }
    }//GEN-LAST:event_btaceptarActionPerformed
    
    private void btbuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btbuscarActionPerformed
      String usuario=txtuser.getText();
      UsuarioRegistrado aux = controlarusuarios.buscarUsuario(usuario);
      if(aux!=null){
          JOptionPane.showMessageDialog(null, "Usuario Encontrado");
          txtnombre.setEnabled(true);
          txtusername.setEnabled(true);
          txtcontra.setEnabled(true);
          txtedad.setEnabled(true);
          txttipouser.setEnabled(true);
          edad=aux.getEdad();
          txtnombre.setText(aux.getNombrecom());
          txtusername.setText(aux.getUsuarios());
          txtcontra.setText(aux.getContraseña());
          
          try{
          txtedad.setText(String.valueOf(edad));
          }catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null, "Ingresar solo numeros en edad");
           txtedad.setText("");
}
          txttipouser.setText(aux.getTipousuario());
      }else{
          JOptionPane.showMessageDialog(null, "Usuario inexistente");
          limpiarcasillas();
      }
    }//GEN-LAST:event_btbuscarActionPerformed
    private void limpiarcasillas(){
          txtuser.setText("");
          txttipouser.setText("");
          txtnombre.setText("");
          txtusername.setText("");
          txtcontra.setText("");
          txtedad.setText("");
    }
    private void txtuserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtuserActionPerformed
        
    }//GEN-LAST:event_txtuserActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btaceptar;
    private javax.swing.JButton btbuscar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField txtcontra;
    private javax.swing.JTextField txtedad;
    private javax.swing.JTextField txtnombre;
    private javax.swing.JTextField txttipouser;
    private javax.swing.JTextField txtuser;
    private javax.swing.JTextField txtusername;
    // End of variables declaration//GEN-END:variables
}
