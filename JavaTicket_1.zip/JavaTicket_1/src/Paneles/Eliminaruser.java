
package Paneles;

import JavaTicket.Usuarios;
import JavaTicket.controlarusuarios;
import javax.swing.JOptionPane;

/**
 *
 * @author villa
 */
public class Eliminaruser extends javax.swing.JPanel {

    public Eliminaruser() {
        initComponents();
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtusuario = new javax.swing.JTextField();
        btaceptar = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        txtcontra = new javax.swing.JPasswordField();

        jPanel1.setBackground(new java.awt.Color(102, 204, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        jLabel1.setText("Eliminar Usuarios");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        jLabel2.setText("Contraseña:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 150, 110, 40));
        jPanel1.add(txtusuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 90, 230, 40));

        btaceptar.setBackground(new java.awt.Color(255, 204, 204));
        btaceptar.setFont(new java.awt.Font("Segoe UI Historic", 1, 14)); // NOI18N
        btaceptar.setText("Aceptar");
        btaceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btaceptarActionPerformed(evt);
            }
        });
        jPanel1.add(btaceptar, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 290, 110, 40));

        jLabel3.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        jLabel3.setText("Username:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 90, 110, 40));
        jPanel1.add(txtcontra, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 150, 230, 40));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 883, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 559, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btaceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btaceptarActionPerformed
        String usuario = txtusuario.getText();
        String contra = new String(txtcontra.getPassword());
        Usuarios aux=controlarusuarios.buscarUsuario(usuario);
        if(aux!=null){
            if(aux.getContraseña().equals(contra))
            controlarusuarios.eliminarCuenta(usuario);
           JOptionPane.showMessageDialog(null, "Usuario Eliminado con exito");
           txtcontra.setText("");
           txtusuario.setText("");
        
        }else if(usuario.isEmpty() || contra.isEmpty()){
            JOptionPane.showMessageDialog(null, "Llene los campos");
        }else
            JOptionPane.showMessageDialog(null, "Usuario inexistente");
        
       
        
            
    }//GEN-LAST:event_btaceptarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btaceptar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPasswordField txtcontra;
    private javax.swing.JTextField txtusuario;
    // End of variables declaration//GEN-END:variables
}
