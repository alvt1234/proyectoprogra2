
package JavaTicket;

import Paneles.Editaruser;
import Paneles.Eliminaruser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class administracionusuarios extends javax.swing.JFrame {
    public administracionusuarios() {
        initComponents();
        this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        panelcrear = new javax.swing.JPanel();
        btregresar = new javax.swing.JButton();
        bteliminar = new javax.swing.JButton();
        bteditar = new javax.swing.JButton();
        btcrear = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panelcrear.setBackground(new java.awt.Color(102, 204, 255));
        panelcrear.setPreferredSize(new java.awt.Dimension(750, 510));

        javax.swing.GroupLayout panelcrearLayout = new javax.swing.GroupLayout(panelcrear);
        panelcrear.setLayout(panelcrearLayout);
        panelcrearLayout.setHorizontalGroup(
            panelcrearLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 740, Short.MAX_VALUE)
        );
        panelcrearLayout.setVerticalGroup(
            panelcrearLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 500, Short.MAX_VALUE)
        );

        jPanel1.add(panelcrear, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 60, 740, 500));

        btregresar.setContentAreaFilled(false);
        btregresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btregresarActionPerformed(evt);
            }
        });
        jPanel1.add(btregresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 500, 120, 45));

        bteliminar.setContentAreaFilled(false);
        bteliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bteliminarActionPerformed(evt);
            }
        });
        jPanel1.add(bteliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 205, 107, 45));

        bteditar.setContentAreaFilled(false);
        bteditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bteditarActionPerformed(evt);
            }
        });
        jPanel1.add(bteditar, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 260, 107, 45));

        btcrear.setContentAreaFilled(false);
        btcrear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btcrearActionPerformed(evt);
            }
        });
        jPanel1.add(btcrear, new org.netbeans.lib.awtextra.AbsoluteConstraints(28, 150, 107, 45));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/admusuarios.png"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 900, 560));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
 private void crearpaneles(JPanel pa){
        pa.setSize(750, 510);
        pa.setLocation(0, 0);
         panelcrear.removeAll();
        panelcrear.add(pa, new org.netbeans.lib.awtextra.AbsoluteConstraints(0,0,-1,-1));
        panelcrear.revalidate();
        panelcrear.repaint(); 
     }
    private void btcrearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btcrearActionPerformed
 
        Crearusuario user=new Crearusuario();
       crearpaneles(user);
      
    }//GEN-LAST:event_btcrearActionPerformed

    private void btregresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btregresarActionPerformed
         Menuprincipal menu =new Menuprincipal();
        menu.setVisible(true);
        dispose();
    }//GEN-LAST:event_btregresarActionPerformed

    private void bteliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bteliminarActionPerformed
       Eliminaruser eliminar=new Eliminaruser();
        crearpaneles(eliminar);
    }//GEN-LAST:event_bteliminarActionPerformed

    private void bteditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bteditarActionPerformed
       Editaruser edit=new Editaruser();
        crearpaneles(edit);
    }//GEN-LAST:event_bteditarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(administracionusuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(administracionusuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(administracionusuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(administracionusuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new administracionusuarios().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btcrear;
    private javax.swing.JButton bteditar;
    private javax.swing.JButton bteliminar;
    private javax.swing.JButton btregresar;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel panelcrear;
    // End of variables declaration//GEN-END:variables
}
