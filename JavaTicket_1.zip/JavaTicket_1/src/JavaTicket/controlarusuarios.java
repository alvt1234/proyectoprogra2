
package JavaTicket;

import java.util.ArrayList;

public class controlarusuarios {
  private static String usuariologueado;

   controlarusuarios controlaruser;
   static ArrayList<UsuarioRegistrado> listaUsuarios = new ArrayList<>();
    
    public controlarusuarios(){
       this.controlaruser=this; 
    }
public static UsuarioRegistrado buscarUsuario(String nombreUser) {
        for (UsuarioRegistrado usuario : listaUsuarios) {
            if (usuario != null && usuario.getUsuarios().equals(nombreUser)) {
                return usuario;
            }
        }
        return null;
    }

     public static UsuarioRegistrado buscartipoUsuario(String nombreUser) {
        for (UsuarioRegistrado usuario : listaUsuarios) {
            if (usuario != null && usuario.getTipousuario().equals(nombreUser)) {
                return usuario;
            }
        }
        return null;
    }
    public static UsuarioRegistrado getContra(String nombreUser){
        for(int i=0;i<listaUsuarios.size();i++){
            UsuarioRegistrado usuario = listaUsuarios.get(i);
            UsuarioRegistrado contra = listaUsuarios.get(i);
            if(usuario!=null){
                if(usuario.getUsuarios().equals(nombreUser)){
                return contra;
                    
                }
            }
        }
        
        return null;
    }
 public static String getTipousuario(String nombreUser) {
    for (UsuarioRegistrado usuario : listaUsuarios) {
        if (usuario != null && usuario.getUsuarios().equals(nombreUser)) {
            return usuario.getTipousuario();
        }
    }
    return null; // Tipo de usuario no encontrado
}

    public static boolean agregarUsuario(UsuarioRegistrado usuario) {
        if (buscarUsuario(usuario.getUsuarios()) == null) {
            listaUsuarios.add(usuario);
            return true;
        }
        return false;
    }

    public static void eliminarCuenta(String nombreUser) {
        UsuarioRegistrado usuario = buscarUsuario(nombreUser);
        if (usuario != null) {
            listaUsuarios.remove(usuario);
        }
    }
    
    
   public static boolean autenticarUsuario(String nombreUser, String contraseña) {
    UsuarioRegistrado usuario = buscarUsuario(nombreUser);
    
    if (usuario != null) {  
        return usuario.getContraseña().equals(contraseña);
        
    }
    
    return false; // Usuario no encontrado
}

    
    public static ArrayList<UsuarioRegistrado> getListaUsuarios() {
        return listaUsuarios;
    }
     public  String getUsuariologueado() {
        return usuariologueado;
    }

    public void setUsuariologueado(String usuariologueado) {
        this.usuariologueado = usuariologueado;
    }
}
