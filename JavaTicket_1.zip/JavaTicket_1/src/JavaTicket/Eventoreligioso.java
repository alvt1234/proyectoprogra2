
package JavaTicket;

import java.util.Date;

public class Eventoreligioso extends Eventoscreados{
    private int seguroGrama;
    private int personasConvertidas;
    private String cancelado;
    public Eventoreligioso(int seguroGrama, int personasConvertidas, int codigo, String descrip, String tit, Date fecha, String tipoevento, double monto, int cantpersonas,String cancelar) {
        super(codigo, descrip, tit, fecha, tipoevento, monto, cantpersonas);
        this.seguroGrama = seguroGrama;
        this.personasConvertidas = personasConvertidas;
        this.cancelado=cancelado;
    }
   


    public int getSeguroGrama() {
        return seguroGrama;
    }

    public void setSeguroGrama(int seguroGrama) {
        this.seguroGrama = seguroGrama;
    }

    public int getPersonasConvertidas() {
        return personasConvertidas;
    }

    public void setPersonasConvertidas(int personasConvertidas) {
        this.personasConvertidas = personasConvertidas;
    }
    public String getCancelar() {
        return cancelado;
    }

    public void setCancelar(String cancelar) {
        this.cancelado = cancelar;
    }

   
    
}
