
package JavaTicket;

import java.util.Date;

public abstract class Eventoscreados {
   private  String titulo,descrip,tipoevento;
   private Date fecha;
    private int codigo;
     private  double monto;
     private int cantpersonas;
    public Eventoscreados( int codigo,String descrip,String tit,Date fecha, String tipoevento, double monto,int cantpersonas) {
       this.codigo=codigo;
       this.tipoevento=tipoevento;
       this.monto=monto;
       this.descrip=descrip;
       this.titulo=tit;
       this.fecha=fecha;
        this.cantpersonas=cantpersonas;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescrip() {
        return descrip;
    }

    public void setDescrip(String descrip) {
        this.descrip = descrip;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }
     public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }
    
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getTipoevento() {
        return tipoevento;
    }

    public void setTipoevento(String tipoevento) {
        this.tipoevento = tipoevento;
    }
    
     public int getCantpersonas() {
        return cantpersonas;
    }

    public void setCantpersonas(int cantpersonas) {
        this.cantpersonas = cantpersonas;
    }
    
    
}
