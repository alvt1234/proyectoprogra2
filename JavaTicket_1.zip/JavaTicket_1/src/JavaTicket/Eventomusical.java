
package JavaTicket;

import java.util.Date;

public class Eventomusical extends Eventoscreados{

    private String tipoMusica;
    private double seguroGrama;
    private String cancelar;

    public Eventomusical(String tipoMusica, double seguroGrama, int codigo, String descrip, String tit, Date fecha, String tipoevento, double monto, int cantpersonas,String cancelar) {
        super(codigo, descrip, tit, fecha, tipoevento, monto, cantpersonas);
        this.tipoMusica = tipoMusica;
        this.seguroGrama = seguroGrama;
        this.cancelar=cancelar;
    }
  
   

    public String getTipoMusica() {
        return tipoMusica;
    }

    public void setTipoMusica(String tipoMusica) {
        this.tipoMusica = tipoMusica;
    }

    public double getSeguroGrama() {
        return seguroGrama;
    }

    public void setSeguroGrama(double seguroGrama) {
        this.seguroGrama = seguroGrama;
    }
    public String getCancelar() {
        return cancelar;
    }

    public void setCancelar(String cancelar) {
        this.cancelar = cancelar;
    }

    
}