
package JavaTicket;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class Controlardeportivo {
    private static String usercreador;
    private boolean cancelado;
    private static double multas,indemnizacion =0.0;
    private static int cantrealizados,montorealizado,montofuturo,cantfuturos,contarcancelados;
    private static String eventosCancelados = "";
    static controlarusuarios control=new controlarusuarios();
    static EditarEvento editar=new EditarEvento();
    static PanelDeportes panel=new PanelDeportes();
    static EliminarEvento eliminar=new EliminarEvento();
    static ArrayList<Eventodeportivo> listadeportes = new ArrayList<>();
    private static List<Object[][]> nombres = new ArrayList<>();
    
     public static boolean agregardeportivos(Eventodeportivo evento){
         usercreador=control.getUsuariologueado();
         
         if (buscarcodigo(evento.getCodigo()) == null) {
            listadeportes.add(evento);
            return true; 
        }
        return false; 
       }

    public static void eliminarEvento(int codigo) {
        Eventodeportivo evento = buscarcodigo(codigo);
        if (evento != null ) {
            listadeportes.remove(evento);
        }
    }
  
    public String cancelar() {
    StringBuilder resultado = new StringBuilder();
    for (Eventodeportivo evento : listadeportes) {
        if(evento.getCancelar().equals("cancelado")){
        indemnizacion = calcularIndemnizacion(evento);
        resultado.append(evento.getCodigo()).append("\n");
         return resultado.toString();
        }
    }
   return null;
    }
    
   //multas
    public double calcularIndemnizacion(Eventodeportivo evento) {
    long eventTime = evento.getFecha().getTime();
    long currentTime = System.currentTimeMillis();
    long diffInDays = (eventTime - currentTime) / (24 * 60 * 60 * 1000);

    if (diffInDays == 1) {
        indemnizacion = evento.getMonto() * 0.5;
      return indemnizacion;
    }
    return 0;
   }
    public String eventosrealizados(Eventodeportivo evento){
    long eventTime = evento.getFecha().getTime();
    long currentTime = System.currentTimeMillis();
    long diffInDays = (eventTime - currentTime) / (24 * 60 * 60 * 1000);
    if (diffInDays < 0) {
    return ""+evento.getCodigo()+"\t"+evento.getTipoevento()+"\t"+evento.getTitulo()+"\t"+evento.getFecha()+"\t"+evento.getMonto();
    }
    return null;
  }
    public String realizados() {
    StringBuilder resultado = new StringBuilder();
    for (Eventodeportivo evento : listadeportes) {
        String events = eventosrealizados(evento);
        if (events != null) { 
            resultado.append(events).append("\n");
        }
    }
    return resultado.toString();
}
public String eventosfuturos(Eventodeportivo evento){
    long eventTime = evento.getFecha().getTime();
    long currentTime = System.currentTimeMillis();
    long diffInDays = (eventTime - currentTime) / (24 * 60 * 60 * 1000);
    if (diffInDays > 0) {
    return ""+evento.getCodigo()+"\t"+evento.getTipoevento()+"\t"+evento.getTitulo()+"\t"+evento.getFecha()+"\t"+evento.getMonto()+"\t"+evento.getCancelar();
    }
    return null;
  }
    public String futuros() {
    StringBuilder resultado = new StringBuilder();
    for (Eventodeportivo evento : listadeportes) {
        String events = eventosfuturos(evento);
        if (events != null) { 
            resultado.append(events).append("\n");
            return resultado.toString();
        }
    }
    return null;
}

     public String eventosporfecha(Eventodeportivo evento){
     return ""+evento.getCodigo()+"\t"+evento.getTipoevento()+"\t"+evento.getTitulo()+"\t"+evento.getFecha()+"\t"+evento.getMonto();
      }
     public String eventoscance(Eventodeportivo evento){
     return ""+evento.getCodigo()+"\t"+evento.getTipoevento()+"\t"+evento.getTitulo()+"\t"+evento.getFecha()+"\t"+getIndemnizacion();
      }
     public String eventosPorFecha() {
    StringBuilder resultado = new StringBuilder();
    
    for (Eventodeportivo evento : listadeportes) {
        resultado.append(eventoscance(evento)).append("\n");
    }

    return resultado.toString();
}
    public String porfecha() {
    StringBuilder resultado = new StringBuilder();
    for (Eventodeportivo evento : listadeportes) {
        String events = eventoscance(evento);
        if (events != null) { 
            resultado.append(events).append("\n");
        }
    }
    return resultado.toString();
}
    //buscarcodigo
    public static Eventodeportivo buscarcodigo(int codigo) {
        for (Eventodeportivo evento : listadeportes) {
            if (evento != null && evento.getCodigo() == codigo) {
                nombres=editar.getEventTableDataList();
                return evento;
            }
        }
        return null; 
    }
    //
   public String events(int code){
       Eventodeportivo eventos=buscarcodigo(code);
       if(eventos.getCodigo()==code && eventos.getCancelar().equals("cancelado")){
       return eventosPorFecha();
       }
       return null;
   }

    public  String getUsercreador() {
        return usercreador;
    }

    public static void setUsercreador(String usercreador) {
        Controlardeportivo.usercreador = usercreador;
    }

    public List<Object[][]> getNombres() {
        return nombres;
    }

    public static void setNombres(List<Object[][]> nombres) {
        Controlardeportivo.nombres = nombres;
    }

   
    public int getCantrealizados() {
        return cantrealizados;
    }

   public void setCantrealizados(int cantrealizados) {
    setCantrealizadosRecursivo(cantrealizados);
}

    private void setCantrealizadosRecursivo(int cantrealizados) {
    if (cantrealizados > 0) {
        this.cantrealizados++;
        setCantrealizadosRecursivo(cantrealizados - 1);
    }
    }


    public int getMontototal() {
        return montorealizado;
    }

    public void setMontototal(int montototal) {
        this.montorealizado = this.montorealizado+montototal;
    }
    public int getMontofuturo() {
        return montofuturo;
    }

    public void setMontofuturo(int montofuturo) {
        this.montofuturo = this.montofuturo+montofuturo;
    }

    public int getCantfuturos() {
        return cantfuturos;
    }

    public void setCantfuturos(int cantfuturos) {
    setCantfuturosRecursivo(cantfuturos);
}
      //recursiva
     private void setCantfuturosRecursivo(int cantfuturos) {
     if (cantfuturos > 0) {
        this.cantfuturos++;
        setCantfuturosRecursivo(cantfuturos - 1);
    }
     }


    public ArrayList<Eventodeportivo> getListadeportes() {
        return listadeportes;
    }

    public double getIndemnizacion() {
        return indemnizacion;
    }

    public void setIndemnizacion(double indemnizacion) {
        this.indemnizacion = indemnizacion;
    }

    public int getContarcancelados() {
        return contarcancelados;
    }

    public  void setContarcancelados(int contarcancelados) {
        this.contarcancelados = this.contarcancelados+contarcancelados;
    }

    
    
    
}
