
package JavaTicket;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

/**
 *
 * @author villa
 */
public class Crearusuario extends javax.swing.JPanel {
  private String seleccion;
  
  
    public Crearusuario() {
        initComponents();
        
       
        cbusuario.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                seleccion = (String) cbusuario.getSelectedItem();
                  if(seleccion == null || seleccion.equals("Usuario")){
                btcrear.setEnabled(false);  
                    JOptionPane.showMessageDialog(null, "Elija el tipo de usuario");
                }else{
                      btcrear.setEnabled(true);
                txtcontra.setEnabled(true);
                txtedad.setEnabled(true);
                txtnombre.setEnabled(true);
                txtuser.setEnabled(true);
           
             }
            }
        });
        
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel6 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtnombre = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        cbusuario = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        txtuser = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtedad = new javax.swing.JTextField();
        btcrear = new javax.swing.JButton();
        txtcontra = new javax.swing.JPasswordField();

        jLabel6.setFont(new java.awt.Font("Yu Gothic Medium", 1, 14)); // NOI18N
        jLabel6.setText("NOMBRE COMPLETO:");

        setBackground(new java.awt.Color(204, 255, 255));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Yu Gothic Medium", 1, 14)); // NOI18N
        jLabel1.setText("NOMBRE COMPLETO:");
        add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 170, -1, -1));

        jLabel2.setFont(new java.awt.Font("Yu Gothic Medium", 1, 16)); // NOI18N
        jLabel2.setText("CREAR USUARIO");
        add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        txtnombre.setEnabled(false);
        add(txtnombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 160, 290, 30));

        jLabel3.setFont(new java.awt.Font("Segoe UI Historic", 1, 16)); // NOI18N
        jLabel3.setText("Tipo de usuario:");
        add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 60, 130, 30));

        cbusuario.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Usuario", "Administrador", "Contenido", "Limitado" }));
        add(cbusuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 60, 100, 30));

        jLabel4.setFont(new java.awt.Font("Yu Gothic Medium", 1, 14)); // NOI18N
        jLabel4.setText("USERNAME: ");
        add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 210, -1, -1));

        txtuser.setEnabled(false);
        add(txtuser, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 200, 200, 30));

        jLabel5.setFont(new java.awt.Font("Yu Gothic Medium", 1, 14)); // NOI18N
        jLabel5.setText("CONTRASEÑA:");
        add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 250, -1, -1));

        jLabel7.setFont(new java.awt.Font("Yu Gothic Medium", 1, 14)); // NOI18N
        jLabel7.setText("EDAD:");
        add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 290, -1, -1));

        txtedad.setEnabled(false);
        add(txtedad, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 280, 90, 30));

        btcrear.setBackground(new java.awt.Color(0, 0, 204));
        btcrear.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        btcrear.setForeground(new java.awt.Color(255, 255, 255));
        btcrear.setText("Crear");
        btcrear.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btcrear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btcrearActionPerformed(evt);
            }
        });
        add(btcrear, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 410, 110, 40));

        txtcontra.setEnabled(false);
        add(txtcontra, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 240, 200, 30));
    }// </editor-fold>//GEN-END:initComponents

    private void btcrearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btcrearActionPerformed
        String users =txtuser.getText();
        String nombre=txtnombre.getText();
        String contra=new String(txtcontra.getPassword());
       
         

        if(txtcontra.getText().isEmpty() || txtedad.getText().isEmpty() || txtnombre.getText().isEmpty() || txtuser.getText().isEmpty() ){         
            JOptionPane.showMessageDialog(null, "Tiene que llenar todos los campos");
        }else{
          try {
         String edadStr = txtedad.getText();
         int edad = Integer.parseInt(edadStr);
         UsuarioRegistrado user=new UsuarioRegistrado(users, contra, seleccion, nombre, edad);
         if (controlarusuarios.agregarUsuario(user)) {
         JOptionPane.showMessageDialog(null, "Usuario registrado.");
        } else {
        JOptionPane.showMessageDialog(null, "El usuario ya existe.");
        }
         txtcontra.setText("");
         txtedad.setText("");
         txtnombre.setText("");
         txtuser.setText("");
         }catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null, "Ingresar solo numeros en edad");
    
    txtedad.setText("");
}
            
       }
       
    }//GEN-LAST:event_btcrearActionPerformed
      
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btcrear;
    private javax.swing.JComboBox<String> cbusuario;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JPasswordField txtcontra;
    private javax.swing.JTextField txtedad;
    private javax.swing.JTextField txtnombre;
    private javax.swing.JTextField txtuser;
    // End of variables declaration//GEN-END:variables
}
