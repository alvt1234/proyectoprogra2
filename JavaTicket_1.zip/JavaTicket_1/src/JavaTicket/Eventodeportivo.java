
package JavaTicket;

import java.util.Date;

public class Eventodeportivo extends Eventoscreados{

    private String equipo1;
    private String equipo2;
    private String tipoDeporte;
    private String cancelar;
    public Eventodeportivo(String equipo1, String equipo2, String tipoDeporte, int codigo, String descrip, String tit, Date fecha, String tipoevento, int monto, int cantpersonas,String cancelar) {
        super(codigo, descrip, tit, fecha, tipoevento, monto, cantpersonas);
        this.equipo1 = equipo1;
        this.equipo2 = equipo2;
        this.tipoDeporte = tipoDeporte;
        this.cancelar=cancelar;
    }

    

    public String getEquipo1() {
        return equipo1;
    }

    public void setEquipo1(String equipo1) {
        this.equipo1 = equipo1;
    }

    public String getEquipo2() {
        return equipo2;
    }

    public void setEquipo2(String equipo2) {
        this.equipo2 = equipo2;
    }

    public String getTipoDeporte() {
        return tipoDeporte;
    }

    public void setTipoDeporte(String tipoDeporte) {
        this.tipoDeporte = tipoDeporte;
    }

    public String getCancelar() {
        return cancelar;
    }

    public void setCancelar(String cancelar) {
        this.cancelar = cancelar;
    }


    
    
}
