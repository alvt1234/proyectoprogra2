
package JavaTicket;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class EditarEvento extends javax.swing.JPanel {

private List<Object[][]> eventTableDataList = new ArrayList<>();

    DefaultTableModel tableModel = new DefaultTableModel();
    private String descrip,titulo,fecha,equipo1,equipo2,renta,personas,seleccion,nombres,cargo;
    private int monto,cantpersonas,codigo,convertidas;
    private int code,cantidad;
    private boolean puede=false,nopuede=false;
    private Date fechatext;
    Eventomusical mus;
    DefaultTableModel model;
    Eventodeportivo depo;
    Eventoreligioso reli;
    Controlardeportivo control=new Controlardeportivo();
    Controlarmusical musical=new Controlarmusical();
    Controlarreligioso religioso=new Controlarreligioso();
    SimpleDateFormat dateFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy",Locale.US);
    private String[] columnNames = {"Nombre", "Edad"};
    private Object[][] data = new Object[0][2];
    
    public EditarEvento() {
        initComponents();
        deshabilitardep();
       
        model = (DefaultTableModel) table.getModel();
        tableModel = new DefaultTableModel(data, columnNames);
        btnombre.setVisible(false);
        cbtipo1.setVisible(false);
        lbtipomusica.setVisible(false);
        txtpersonconvertidas.setVisible(false);
        lbconvertidas.setVisible(false);
        paneltabla.setVisible(false);
        btver.setVisible(false);
        seleccion= (String)cbtipo1.getSelectedItem();
        //code=txtcodigo.getText();
        
    }

    private void deshabilitardep(){
        txtequipo1.setVisible(false);
        txtequipo2.setVisible(false);
        cbtipo.setVisible(false);
        lbequipo1.setVisible(false);
        lbequipo2.setVisible(false);
        lbtipodeporte.setVisible(false);
        btfilas.setVisible(false);
        paneltabla.setVisible(false);
      //  table.setVisible(false);
        
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        txtcodigo = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txttitulo = new javax.swing.JTextField();
        txtdescrip = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtfecha = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtmonto = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtcantpersonas = new javax.swing.JTextField();
        lbequipo1 = new javax.swing.JLabel();
        txtequipo1 = new javax.swing.JTextField();
        lbequipo2 = new javax.swing.JLabel();
        txtequipo2 = new javax.swing.JTextField();
        lbtipodeporte = new javax.swing.JLabel();
        cbtipo = new javax.swing.JComboBox<>();
        lbconvertidas = new javax.swing.JLabel();
        txtpersonconvertidas = new javax.swing.JTextField();
        cbbuscar = new javax.swing.JButton();
        lbtipomusica = new javax.swing.JLabel();
        cbtipo1 = new javax.swing.JComboBox<>();
        cbaceptar = new javax.swing.JButton();
        btfilas = new javax.swing.JButton();
        paneltabla = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        btver = new javax.swing.JButton();
        btnombre = new javax.swing.JButton();
        lbpend = new javax.swing.JLabel();

        setPreferredSize(new java.awt.Dimension(750, 510));

        jPanel1.setBackground(new java.awt.Color(204, 255, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(750, 510));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel2.setText("CODIGO DEL EVENTO:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, -1, -1));

        jLabel1.setFont(new java.awt.Font("Yu Gothic Medium", 1, 14)); // NOI18N
        jLabel1.setText("EDITAR EVENTO");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));
        jPanel1.add(txtcodigo, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 50, 130, 30));

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel3.setText("Titulo Evento:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 110, -1, -1));

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel4.setText("Descripcion:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 150, -1, -1));
        jPanel1.add(txttitulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 100, 200, 30));
        jPanel1.add(txtdescrip, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 140, 200, 30));

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel5.setText("Fecha:");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 190, -1, -1));
        jPanel1.add(txtfecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 180, 200, 30));

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel6.setText("Monto:");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 230, -1, -1));
        jPanel1.add(txtmonto, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 220, 200, 30));

        jLabel9.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel9.setText("Cantidad personas:");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 270, -1, -1));
        jPanel1.add(txtcantpersonas, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 260, 160, 30));

        lbequipo1.setFont(new java.awt.Font("Segoe UI Emoji", 1, 14)); // NOI18N
        lbequipo1.setText("Equipo 1:");
        jPanel1.add(lbequipo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 310, 70, 30));

        txtequipo1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtequipo1ActionPerformed(evt);
            }
        });
        jPanel1.add(txtequipo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 310, 200, 30));

        lbequipo2.setFont(new java.awt.Font("Segoe UI Emoji", 1, 14)); // NOI18N
        lbequipo2.setText("Equipo 2:");
        jPanel1.add(lbequipo2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 350, 130, 30));
        jPanel1.add(txtequipo2, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 350, 200, 30));

        lbtipodeporte.setFont(new java.awt.Font("Segoe UI Emoji", 1, 14)); // NOI18N
        lbtipodeporte.setText("Tipo deporte:");
        jPanel1.add(lbtipodeporte, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 390, 110, 30));

        cbtipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "FUTBOL", "TENIS", "RUGBY", "BASEBALL" }));
        jPanel1.add(cbtipo, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 390, 110, 30));

        lbconvertidas.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        lbconvertidas.setText("Personas Convertidas:");
        jPanel1.add(lbconvertidas, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 470, -1, -1));
        jPanel1.add(txtpersonconvertidas, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 460, 160, 30));

        cbbuscar.setBackground(new java.awt.Color(255, 204, 204));
        cbbuscar.setFont(new java.awt.Font("Segoe UI Historic", 1, 14)); // NOI18N
        cbbuscar.setText("Buscar");
        cbbuscar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        cbbuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbbuscarActionPerformed(evt);
            }
        });
        jPanel1.add(cbbuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 40, 120, 40));

        lbtipomusica.setFont(new java.awt.Font("Segoe UI Historic", 1, 16)); // NOI18N
        lbtipomusica.setText("Tipo musica:");
        jPanel1.add(lbtipomusica, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 100, 150, 30));

        cbtipo1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "POP", "ROCK", "RAP", "CLASICA", "REGGEATON", "OTRO" }));
        jPanel1.add(cbtipo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 100, 110, 30));

        cbaceptar.setBackground(new java.awt.Color(255, 204, 204));
        cbaceptar.setFont(new java.awt.Font("Segoe UI Historic", 1, 14)); // NOI18N
        cbaceptar.setText("Aceptar");
        cbaceptar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        cbaceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbaceptarActionPerformed(evt);
            }
        });
        jPanel1.add(cbaceptar, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 450, 120, 40));

        btfilas.setText("Agregar Fila");
        btfilas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btfilasActionPerformed(evt);
            }
        });
        jPanel1.add(btfilas, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 340, -1, -1));

        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "EQUIPO 1", "EQUIPO 2"
            }
        ));
        jScrollPane2.setViewportView(table);

        javax.swing.GroupLayout paneltablaLayout = new javax.swing.GroupLayout(paneltabla);
        paneltabla.setLayout(paneltablaLayout);
        paneltablaLayout.setHorizontalGroup(
            paneltablaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(paneltablaLayout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 330, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        paneltablaLayout.setVerticalGroup(
            paneltablaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(paneltablaLayout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jPanel1.add(paneltabla, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 140, 330, 180));

        btver.setText("Cargo");
        btver.setBorderPainted(false);
        btver.setContentAreaFilled(false);
        btver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btverActionPerformed(evt);
            }
        });
        jPanel1.add(btver, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 310, 130, 40));

        btnombre.setText("Nombre musicos");
        btnombre.setBorderPainted(false);
        btnombre.setContentAreaFilled(false);
        btnombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnombreActionPerformed(evt);
            }
        });
        jPanel1.add(btnombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 310, 130, 40));

        lbpend.setFont(new java.awt.Font("Segoe UI Historic", 0, 14)); // NOI18N
        jPanel1.add(lbpend, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 10, 180, 30));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void txtequipo1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtequipo1ActionPerformed
       
    }//GEN-LAST:event_txtequipo1ActionPerformed

    private void limpiar(){
        txtdescrip.setText("");
            txttitulo.setText("");
            txtfecha.setText("");
            txtmonto.setText("");
            txtcantpersonas.setText("");
    }
    private void cbbuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbbuscarActionPerformed
       
        try {
        code = Integer.parseInt(txtcodigo.getText());
            System.out.println("code "+code+"codigo "+codigo);
        
            System.out.println("entraqui");
            depo = Controlardeportivo.buscarcodigo(code);
            mus = Controlarmusical.buscarcodigo(code);
            reli = Controlarreligioso.buscarcodigo(code);
            
          
            System.out.println("aqui");
            if (depo != null || mus != null || reli!=null) {
                JOptionPane.showMessageDialog(null, "Evento encontrado");
            
                if (depo != null && depo.getCodigo() == code) {
                    
                   txtequipo1.setVisible(true);
                    txtequipo2.setVisible(true);
                    cbtipo.setVisible(true);
                    lbequipo1.setVisible(true);
                    lbequipo2.setVisible(true);
                    lbtipodeporte.setVisible(true);
                    btfilas.setVisible(true);
                    paneltabla.setVisible(true);
                    cbtipo1.setVisible(false);
                    lbtipomusica.setVisible(false);
                    txtdescrip.setText(depo.getDescrip());
                    txttitulo.setText(depo.getTitulo());
                    txtfecha.setText(String.valueOf(depo.getFecha()));
                    txtequipo1.setText(depo.getEquipo1());
                    txtequipo2.setText(depo.getEquipo2());
                    txtcantpersonas.setText(String.valueOf(depo.getCantpersonas()));
                    txtmonto.setText(String.valueOf(depo.getMonto()));
                }
                
                
                 if (mus != null && mus.getCodigo() == code) {
                    deshabilitardep();
                    cbtipo1.setVisible(true);
                    lbtipomusica.setVisible(true);
                    btnombre.setVisible(true);
                    btnombre.setContentAreaFilled(true);
                    btver.setVisible(true);
                    btver.setContentAreaFilled(true);
                    txtdescrip.setText(mus.getDescrip());
                    txttitulo.setText(mus.getTitulo());
                    txtfecha.setText(String.valueOf(mus.getFecha()));
                    txtcantpersonas.setText(String.valueOf(mus.getCantpersonas()));
                    txtmonto.setText(String.valueOf(mus.getMonto()));
                }

               if (reli != null && reli.getCodigo() == code) {
                    deshabilitardep();
                    cbtipo1.setVisible(false);
                    txtdescrip.setText(reli.getDescrip());
                    txttitulo.setText(reli.getTitulo());
                    txtfecha.setText(String.valueOf(reli.getFecha()));
                    txtcantpersonas.setText(String.valueOf(reli.getCantpersonas()));
                    txtmonto.setText(String.valueOf(reli.getMonto()));
                    txtpersonconvertidas.setVisible(true);
                    lbconvertidas.setVisible(true);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Evento no encontrado");
            }
         
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null, "Ingrese un codigo");
    }
    }//GEN-LAST:event_cbbuscarActionPerformed

    private void cbaceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbaceptarActionPerformed
        
            descrip=txtdescrip.getText();
            titulo=txttitulo.getText();
            fecha=txtfecha.getText();
             try {
            fechatext = dateFormat.parse(fecha);
          } catch (Exception e) {
            e.printStackTrace();
           }
            equipo1=txtequipo1.getText();
            equipo2=txtequipo2.getText(); 
            renta=txtmonto.getText();
            personas=txtcantpersonas.getText();
        if(depo!=null && depo.getCodigo() == code){
        if (txttitulo.getText().isEmpty() || txtdescrip.getText().isEmpty() || txtfecha.getText().isEmpty() || txtequipo1.getText().isEmpty() || txtequipo2.getText().isEmpty() || nopuede==false) {
            JOptionPane.showMessageDialog(null, "Tiene que llenar todos los campos.");
        } else {
            evitarerrores();
            tabla();
            JOptionPane.showMessageDialog(null, "Editado correctamente");
            try {
            monto = Integer.parseInt(renta);
           cantpersonas=Integer.parseInt(personas);
            depo.setDescrip(descrip);
            depo.setTitulo(titulo);
            depo.setEquipo1(equipo1);
            depo.setEquipo2(equipo2);
            depo.setFecha(fechatext);
            depo.setMonto(monto);
            depo.setCantpersonas(cantpersonas);
            System.out.println(depo.getDescrip());
            System.out.println(depo.getTitulo());
            System.out.println(depo.getEquipo1());
            System.out.println(depo.getEquipo2());
            System.out.println(depo.getFecha());
            System.out.println(depo.getMonto());
            limpiar();
            } catch (NumberFormatException e) {
           JOptionPane.showMessageDialog(null, "Ingresar solo numeros");
           }
           }
            
        }else
        if(mus!= null && mus.getCodigo() == code){
           if (txttitulo.getText().isEmpty() || txtdescrip.getText().isEmpty() || txtfecha.getText().isEmpty() || txtmonto.getText().isEmpty()|| cbtipo1.getSelectedItem()==null) {
           JOptionPane.showMessageDialog(null, "Tiene que llenar todos los campos.");
        } else if(puede==false){
            JOptionPane.showMessageDialog(null, "No ha agregado a los musicos.");
        }else{
            try {
            monto = Integer.parseInt(renta);
           cantpersonas=Integer.parseInt(personas);
                JOptionPane.showMessageDialog(null, "Editado correctamente");
                evitarerrores();
                mus.setDescrip(descrip);
                mus.setTitulo(titulo);
                mus.setFecha(fechatext);
                mus.setMonto(monto);
                mus.setSeguroGrama(monto*0.3);
                mus.setTipoMusica(titulo);
                mus.setCantpersonas(cantpersonas);
                mus.setTipoMusica(seleccion);
                limpiar();
                }catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null, "Ingresar solo numeros");
        }
             } 
            }else
        if(reli!= null && reli.getCodigo() == code){
           if (txttitulo.getText().isEmpty() || txtdescrip.getText().isEmpty() || txtfecha.getText().isEmpty() || txtmonto.getText().isEmpty() || txtpersonconvertidas.getText().isEmpty()) {
           JOptionPane.showMessageDialog(null, "Tiene que llenar todos los campos.");
        } else{
               try {
            monto = Integer.parseInt(renta);
           cantpersonas=Integer.parseInt(personas);
                JOptionPane.showMessageDialog(null, "Editado correctamente");   
                evitarerrores();
                reli.setDescrip(descrip);
                reli.setTitulo(titulo);
                reli.setFecha(fechatext);
                reli.setMonto(monto);
                reli.setCantpersonas(cantpersonas);
                reli.setPersonasConvertidas(convertidas);
                limpiar();
                 }catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null, "Ingresar solo numeros");
        }
             } 
            }
            
            txtequipo1.setText("");
            txtequipo2.setText("");
            
    }//GEN-LAST:event_cbaceptarActionPerformed

    private void evitarerrores(){
        try {
                monto = Integer.parseInt(renta);
                cantpersonas= Integer.parseInt(personas);
                codigo=Integer.parseInt(txtcodigo.getText());
                convertidas=Integer.parseInt(txtpersonconvertidas.getText());
            } catch (NumberFormatException e) {
                System.out.println("monto");
            }
           
    }
    private void tabla(){
        int rowCount = model.getRowCount();
        data = new Object[rowCount][2];
        System.out.println("a" + rowCount);
        if (rowCount == 0) {
            JOptionPane.showMessageDialog(null, "Necesita agregar los nombres a la tabla antes de editar.");
        } 
         for (int i = 0; i < rowCount; i++) {
                data[i][0] = model.getValueAt(i, 0);
                data[i][1] = model.getValueAt(i, 1);
                System.out.println("Equipo 1: " + data[i][0] + ", Equipo 2: " + data[i][1]);
            }
         nopuede=true;
         eventTableDataList.add(data);
    }
    private void loadEventData(int eventIndex) {
     model = (DefaultTableModel) table.getModel();

    if (eventIndex >= 0 && eventIndex < eventTableDataList.size()) {
        data = eventTableDataList.get(eventIndex);
        
        for (int i = 0; i < data.length; i++) {
            model.addRow(data[i]);
        }
    }
}
    private void btfilasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btfilasActionPerformed
        model.addRow(new Object[]{"", ""});
        tabla();
    }//GEN-LAST:event_btfilasActionPerformed

    private void btnombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnombreActionPerformed
       puede=true;
       String cantnombres = JOptionPane.showInputDialog("Cantidad de musicos");
        cantidad=Integer.parseInt(cantnombres);
       for(int i=0;i<cantidad;i++){
            nombres = JOptionPane.showInputDialog("Nombre #"+i+":");
            cargo = JOptionPane.showInputDialog("Cargo de "+nombres);
            musical.guardarmusicos(nombres, cargo);
       }
       
    }//GEN-LAST:event_btnombreActionPerformed

    private void btverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btverActionPerformed
       musicos muss=new musicos();
       muss.setVisible(true);
    }//GEN-LAST:event_btverActionPerformed

    public List<Object[][]> getEventTableDataList() {
        return eventTableDataList;
    }

    public void setEventTableDataList(List<Object[][]> eventTableDataList) {
        this.eventTableDataList = eventTableDataList;
    }
 
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btfilas;
    private javax.swing.JButton btnombre;
    private javax.swing.JButton btver;
    private javax.swing.JButton cbaceptar;
    private javax.swing.JButton cbbuscar;
    private javax.swing.JComboBox<String> cbtipo;
    private javax.swing.JComboBox<String> cbtipo1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lbconvertidas;
    private javax.swing.JLabel lbequipo1;
    private javax.swing.JLabel lbequipo2;
    private javax.swing.JLabel lbpend;
    private javax.swing.JLabel lbtipodeporte;
    private javax.swing.JLabel lbtipomusica;
    private javax.swing.JPanel paneltabla;
    private javax.swing.JTable table;
    private javax.swing.JTextField txtcantpersonas;
    private javax.swing.JTextField txtcodigo;
    private javax.swing.JTextField txtdescrip;
    private javax.swing.JTextField txtequipo1;
    private javax.swing.JTextField txtequipo2;
    private javax.swing.JTextField txtfecha;
    private javax.swing.JTextField txtmonto;
    private javax.swing.JTextField txtpersonconvertidas;
    private javax.swing.JTextField txttitulo;
    // End of variables declaration//GEN-END:variables
}
