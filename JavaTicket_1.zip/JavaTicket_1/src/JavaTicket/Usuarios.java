
package JavaTicket;

public class Usuarios {
   protected String usuarios;
   protected String contraseña;
   protected String usercreador;
  
   public Usuarios(String usuarios,String contraseña){
       this.usuarios=usuarios;
       this.contraseña=contraseña;
        usercreador=usuarios;
   }

    public String getUsuarios() {
        return usuarios;
    }

    public void setUsuarios(String usuarios) {
        this.usuarios = usuarios;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public String getUsercreador() {
        return usercreador;
    }

    public void setUsercreador(String usercreador) {
        this.usercreador = usercreador;
    }
    
  


}
