
package JavaTicket;

import javax.swing.JOptionPane;

/**
 *
 * @author villa
 */
public class EliminarEvento extends javax.swing.JPanel {

    controlarusuarios control=new controlarusuarios();
    Controlardeportivo depor=new Controlardeportivo();
    Controlarreligioso religioso=new Controlarreligioso();
    Controlarmusical musical=new Controlarmusical();
    static PanelDeportes panel=new PanelDeportes();
    private static String verificar="nocancelado";
    private static boolean multa;
    long eventTime;
    private double indemnizacion;
    public EliminarEvento() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtcodigo = new javax.swing.JTextField();
        bteliminar = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();

        jPanel1.setBackground(new java.awt.Color(204, 255, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(750, 510));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Yu Gothic Medium", 1, 14)); // NOI18N
        jLabel1.setText("ELIMINAR  EVENTO");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel2.setText("CODIGO DEL EVENTO:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, -1, -1));
        jPanel1.add(txtcodigo, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 62, 130, 30));

        bteliminar.setBackground(new java.awt.Color(255, 204, 204));
        bteliminar.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        bteliminar.setText("Eliminar");
        bteliminar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        bteliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bteliminarActionPerformed(evt);
            }
        });
        jPanel1.add(bteliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 60, 110, 40));

        jLabel3.setText("SOLO EL USUARIO QUE CREO EL EVENTO PUEDE ELIMINARLO");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 130, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void bteliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bteliminarActionPerformed
        int code=Integer.parseInt(txtcodigo.getText());
        Eventodeportivo depo=Controlardeportivo.buscarcodigo(code);
        Eventomusical mus=Controlarmusical.buscarcodigo(code);
        Eventoreligioso reli=Controlarreligioso.buscarcodigo(code);
       
        try{
        if (depo != null) {
        if (depo.getCodigo() == code && control.getUsuariologueado().equals(depor.getUsercreador())) {
           depor.setContarcancelados(1);
           depo.setCancelar("cancelado");
            JOptionPane.showMessageDialog(null, "Evento cancelado");
           System.out.println("indemnizacion"+depor.getIndemnizacion());
           txtcodigo.setText("");
           }
           }else
        if(mus!=null){
           if(mus.getCodigo()==code && control.getUsuariologueado().equals(musical.getUsercreador())){
               musical.setContarcancelados(1);
               mus.setCancelar("cancelado");
            System.out.println("indemnizacion"+depor.getIndemnizacion());
               Controlarmusical.cancelarevento(code, mus.getTipoevento(), mus.getTitulo(), String.valueOf(mus.getFecha()), indemnizacion);
           JOptionPane.showMessageDialog(null, "Evento cancelado");
           txtcodigo.setText("");
            }
        }else
        if(reli!=null){
            if(reli.getCodigo()==code && control.getUsuariologueado().equals(religioso.getUsercreador())){
                religioso.setContarcancelados(1);
                reli.setCancelar("cancelado");
           JOptionPane.showMessageDialog(null, "Evento cancelado");
           txtcodigo.setText("");
            }
            }else
               JOptionPane.showMessageDialog(null, "No has creado dicho evento.");
       
            
            
        }catch(java.lang.NullPointerException e){
            JOptionPane.showMessageDialog(null, "Codigo Inexistente");
        }
        
        
    }//GEN-LAST:event_bteliminarActionPerformed

    public String getVerificar() {
        return verificar;
    }

    public void setVerificar(String verificar) {
        EliminarEvento.verificar = verificar;
    }

    public boolean isMulta() {
        return multa;
    }

   


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bteliminar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField txtcodigo;
    // End of variables declaration//GEN-END:variables
}
