
package JavaTicket;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Controlarmusical {
    static ArrayList<Eventomusical> listamusical = new ArrayList<>();
    static ArrayList<String> musicos=new ArrayList<>();
    private static String usercreador; 
    private static double indemnizacion,montototal ;
    private static int cantrealizados,montofuturo,cantfuturos,contarcancelados;
    public static String eventsrealizados="";
    static controlarusuarios control=new controlarusuarios();
     UsuarioRegistrado aux=controlarusuarios.buscarUsuario(control.getUsuariologueado());
     
     //Agregar
     public static boolean agregarmusical(Eventomusical evento){
         usercreador=control.getUsuariologueado();
         if (buscarcodigo(evento.getCodigo()) == null) {
            listamusical.add(evento);
            return true; 
        }
        return false; 
       }
    //eliminar
    public static void eliminarEvento(int codigo) {
        Eventomusical evento = buscarcodigo(codigo);
              if (evento != null ) {
            listamusical.remove(evento);
        }
    }
    //cancelarevento
    public static String cancelarevento(int code, String tipo, String titulo, String fecha, double multa) {    
    String resultado = "\n" + code + "\t" + tipo + "\t" + titulo + "\t" + fecha;
    if (multa > 0) {
        resultado += "\t" + multa;
    } else {
        resultado += "\t0";
    }

    return resultado;
   }

    //buscarcodigo
    public static Eventomusical buscarcodigo(int codigo) {
        for (Eventomusical evento : listamusical) {
            if (evento != null && evento.getCodigo() == codigo) {
                return evento;
            }
        }
        return null; 
    }
    
    //eventosrealizados
     public String eventosrealizados(Eventomusical evento){
    long eventTime = evento.getFecha().getTime();
    long currentTime = System.currentTimeMillis();
    long diffInDays = (eventTime - currentTime) / (24 * 60 * 60 * 1000);
    if (diffInDays < 0) {
    return ""+evento.getCodigo()+"\t"+evento.getTipoevento()+"\t"+evento.getTitulo()+"\t"+evento.getFecha()+"\t"+evento.getMonto();
    }
    return null;
  }
     //realizados
    public String realizados() {
    StringBuilder resultado = new StringBuilder();
    for (Eventomusical evento : listamusical) {
        String events = eventosrealizados(evento);
        if (events != null) { 
            resultado.append(events).append("\n");
        }
    }
    return resultado.toString();
}

    //eventosfuturos
public String eventosfuturos(Eventomusical evento){
    long eventTime = evento.getFecha().getTime();
    long currentTime = System.currentTimeMillis();
    long diffInDays = (eventTime - currentTime) / (24 * 60 * 60 * 1000);
    if (diffInDays > 0) {
    return ""+evento.getCodigo()+"\t"+evento.getTipoevento()+"\t"+evento.getTitulo()+"\t"+evento.getFecha()+"\t"+evento.getMonto()+"\t"+evento.getCancelar();
    }
    return null;
  }
//futuros
    public String futuros() {
    StringBuilder resultado = new StringBuilder();
    for (Eventomusical evento : listamusical) {
        String events = eventosfuturos(evento);
        if (events != null) { 
            resultado.append(events).append("\n");
            return resultado.toString();
        }
    }
    return null;
}

    public String events(int code){
       Eventomusical eventos=buscarcodigo(code);
       if(eventos.getCodigo()==code && eventos.getCancelar().equals("cancelado")){
       return eventosPorFecha();
       }
       return null;
   }
    //calcular multa
    public double calcularIndemnizacion(Eventomusical evento) {
    long eventTime = evento.getFecha().getTime();
    long currentTime = System.currentTimeMillis();
    long diffInDays = (eventTime - currentTime) / (24 * 60 * 60 * 1000);
    indemnizacion = 0;

    if (diffInDays == 1) {
        indemnizacion = evento.getMonto() * 0.5;
         return indemnizacion;
    }
    return 0;
}
    //cancelar
   public String cancelar() {
    StringBuilder resultado = new StringBuilder();
    for (Eventomusical evento : listamusical) {
        if(evento.getCancelar().equals("cancelado")){
        indemnizacion = calcularIndemnizacion(evento);
        resultado.append(evento.getCodigo()).append("\n");
         return resultado.toString();
        }
    }
   return null;
    }
    //eventos por fecha
    public String eventosporfecha(Eventomusical evento){
     return ""+evento.getCodigo()+"\t"+evento.getTipoevento()+"\t"+evento.getTitulo()+"\t"+evento.getFecha()+"\t"+evento.getMonto();
      }
     public String eventoscance(Eventomusical evento){
     return ""+evento.getCodigo()+"\t"+evento.getTipoevento()+"\t"+evento.getTitulo()+"\t"+evento.getFecha()+"\t"+getIndemnizacion();
      }
     public String eventosPorFecha() {
    StringBuilder resultado = new StringBuilder();
    
    for (Eventomusical evento : listamusical) {
        resultado.append(eventoscance(evento)).append("\n");
    }

    return resultado.toString();
}
    public String porfecha() {
    StringBuilder resultado = new StringBuilder();
    for (Eventomusical evento : listamusical) {
        String events = eventosporfecha(evento);
        if (events != null) { 
            resultado.append(events).append("\n");
        }
    }
    return resultado.toString();
}
    //agregar musicos
    public String guardarmusicos(String nombres,String cargo){
        return nombres+cargo;
    }

    public boolean guardanmusicos2(String nombres,String cargo){
        String musico=guardarmusicos(nombres, cargo);
        if(guardarmusicos(nombres, cargo) ==null){
            musicos.add(musico);
        }
        return false;
    }
    public boolean editarmusicos2(String nombres, String nuevoNombres, String nuevoCargo) {
    String musico = guardarmusicos(nombres, nuevoCargo); 
    if (musico != null) {
        int indice = musicos.indexOf(musico);
        if (indice != -1) {
            musicos.set(indice, guardarmusicos(nuevoNombres, nuevoCargo));
            return true;
        }
    }
    return false;
}

    public ArrayList<String> getMusicos() {
        return musicos;
    }

    


    //setters and getters
    public  String getUsercreador() {
        return usercreador;
    }

    public static void setUsercreador(String usercreador) {
        Controlarmusical.usercreador = usercreador;
    }
    public int getCantrealizados() {
        return cantrealizados;
    }

    public void setCantrealizados(int cantrealizados) {
    setCantrealizadosRecursivo(cantrealizados);
    }

    private void setCantrealizadosRecursivo(int cantrealizados) {
    if (cantrealizados > 0) {
        this.cantrealizados++;
        setCantrealizadosRecursivo(cantrealizados - 1);
    }
   }


    public double getMontototal() {
        return montototal;
    }

    public void setMontototal(double montototal) {
        this.montototal = this.montototal+montototal;
    }
    public int getMontofuturo() {
        return montofuturo;
    }

    public void setMontofuturo(int montofuturo) {
        this.montofuturo = this.montofuturo+montofuturo;
    }

    public int getCantfuturos() {
        return cantfuturos;
    }

    public void setCantfuturos(int cantfuturos) {
       this.cantfuturos = this.cantfuturos+cantfuturos;
    }

    public ArrayList<Eventomusical> getListamusical() {
        return listamusical;
    }
    public double getIndemnizacion() {
        return indemnizacion;
    }

    public void setIndemnizacion(double indemnizacion) {
        this.indemnizacion = indemnizacion;
    }
    public int getContarcancelados() {
        return contarcancelados;
    }

    public  void setContarcancelados(int contarcancelados) {
        this.contarcancelados = this.contarcancelados+contarcancelados;
    }
    
}
