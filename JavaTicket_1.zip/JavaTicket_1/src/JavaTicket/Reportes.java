
package JavaTicket;

public class Reportes extends javax.swing.JFrame {
    Controlardeportivo control=new Controlardeportivo();
    public Reportes() {
        initComponents();
        this.setLocationRelativeTo(null);
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btregresar = new javax.swing.JButton();
        btperfil = new javax.swing.JButton();
        bteventsrealizados = new javax.swing.JButton();
        btingresogenerado = new javax.swing.JButton();
        bteventscancelados = new javax.swing.JButton();
        bteventsfuturos = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btregresar.setContentAreaFilled(false);
        btregresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btregresarActionPerformed(evt);
            }
        });
        jPanel1.add(btregresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 500, 140, 40));

        btperfil.setContentAreaFilled(false);
        btperfil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btperfilActionPerformed(evt);
            }
        });
        jPanel1.add(btperfil, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 360, 270, 40));

        bteventsrealizados.setContentAreaFilled(false);
        bteventsrealizados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bteventsrealizadosActionPerformed(evt);
            }
        });
        jPanel1.add(bteventsrealizados, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 130, 270, 40));

        btingresogenerado.setContentAreaFilled(false);
        btingresogenerado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btingresogeneradoActionPerformed(evt);
            }
        });
        jPanel1.add(btingresogenerado, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 300, 270, 40));

        bteventscancelados.setContentAreaFilled(false);
        bteventscancelados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bteventscanceladosActionPerformed(evt);
            }
        });
        jPanel1.add(bteventscancelados, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 250, 270, 40));

        bteventsfuturos.setContentAreaFilled(false);
        bteventsfuturos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bteventsfuturosActionPerformed(evt);
            }
        });
        jPanel1.add(bteventsfuturos, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 190, 270, 40));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/reportes.png"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 880, 570));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btregresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btregresarActionPerformed
       Menuprincipal menu=new Menuprincipal();
       menu.setVisible(true);
       dispose();
    }//GEN-LAST:event_btregresarActionPerformed

    private void bteventsrealizadosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bteventsrealizadosActionPerformed
        EventosRealizados realizados=new EventosRealizados(control);
        realizados.setVisible(true);
        dispose();
    }//GEN-LAST:event_bteventsrealizadosActionPerformed

    private void bteventscanceladosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bteventscanceladosActionPerformed
       cancelados cancelados=new cancelados();
       cancelados.setVisible(true);
       dispose();
    }//GEN-LAST:event_bteventscanceladosActionPerformed

    private void bteventsfuturosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bteventsfuturosActionPerformed
     Eventosfuturos futuro=new Eventosfuturos();
     futuro.setVisible(true);
     dispose();
    }//GEN-LAST:event_bteventsfuturosActionPerformed

    private void btingresogeneradoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btingresogeneradoActionPerformed
        IngresoGenerado ingreso=new IngresoGenerado();
        ingreso.setVisible(true);
        dispose();
    }//GEN-LAST:event_btingresogeneradoActionPerformed

    private void btperfilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btperfilActionPerformed
       Perfil perfil=new Perfil();
       perfil.setVisible(true);
       dispose();
    }//GEN-LAST:event_btperfilActionPerformed

  

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bteventscancelados;
    private javax.swing.JButton bteventsfuturos;
    private javax.swing.JButton bteventsrealizados;
    private javax.swing.JButton btingresogenerado;
    private javax.swing.JButton btperfil;
    private javax.swing.JButton btregresar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
