
package JavaTicket;

public class UsuarioRegistrado extends Usuarios {
 
    protected String nombrecom;
    protected int edad;
     protected String tipousuario;
     
    public UsuarioRegistrado(String usuarios, String contraseña, String tipousuario, String nombrecomp, int edad) {
        super(usuarios, contraseña);
        this.edad=edad;
        this.nombrecom=nombrecomp;
        this.tipousuario=tipousuario;
        
    }

    public String getNombrecom() {
        return nombrecom;
    }

    public void setNombrecom(String nombrecom) {
        this.nombrecom = nombrecom;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }
    public String getTipousuario() {
        return tipousuario;
    }

    public void setTipousuario(String tipousuario) {
        this.tipousuario = tipousuario;
    }
  
}

