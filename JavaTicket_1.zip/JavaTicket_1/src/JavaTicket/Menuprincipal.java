
package JavaTicket;

import javax.swing.JOptionPane;

/**
 *
 * @author villa
 */
public class Menuprincipal extends javax.swing.JFrame {
     controlarusuarios control=new controlarusuarios();
    Crearusuario crearuser= new Crearusuario();
    public Menuprincipal() {
        initComponents();
        this.setLocationRelativeTo(null);
        UsuarioRegistrado aux=controlarusuarios.buscarUsuario(control.getUsuariologueado());
        System.out.println("entra"+control.getUsuariologueado());
        if (aux != null) {
            System.out.println("entra"+control.getUsuariologueado());
            switch (aux.getTipousuario()) {
                case "Administrador" -> {
                    btusuarios.setVisible(true);
                }
                case "Contenido" -> {
                    btusuarios.setVisible(false);
                }
                case "Limitado" -> {
                    btusuarios.setVisible(false);
                }
                default -> {
                    btusuarios.setVisible(true);
                }
            }
        }
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        Login = new javax.swing.JButton();
        btadmeventos = new javax.swing.JButton();
        btreportes = new javax.swing.JButton();
        btusuarios = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jButton1.setContentAreaFilled(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 500, 90, 40));

        Login.setBackground(new java.awt.Color(0, 51, 153));
        Login.setFont(new java.awt.Font("Segoe UI", 1, 19)); // NOI18N
        Login.setForeground(new java.awt.Color(255, 255, 255));
        Login.setBorderPainted(false);
        Login.setContentAreaFilled(false);
        Login.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LoginActionPerformed(evt);
            }
        });
        getContentPane().add(Login, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 500, 160, 40));

        btadmeventos.setContentAreaFilled(false);
        btadmeventos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btadmeventosActionPerformed(evt);
            }
        });
        getContentPane().add(btadmeventos, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 140, 320, 40));

        btreportes.setContentAreaFilled(false);
        btreportes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btreportesActionPerformed(evt);
            }
        });
        getContentPane().add(btreportes, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 200, 310, 40));

        btusuarios.setBackground(new java.awt.Color(204, 204, 204));
        btusuarios.setFont(new java.awt.Font("Franklin Gothic Book", 1, 20)); // NOI18N
        btusuarios.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Administración de usuarios.png"))); // NOI18N
        btusuarios.setAlignmentY(5.0F);
        btusuarios.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btusuarios.setBorderPainted(false);
        btusuarios.setContentAreaFilled(false);
        btusuarios.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btusuarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btusuariosActionPerformed(evt);
            }
        });
        getContentPane().add(btusuarios, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 270, 310, 40));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/menu.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 900, 560));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        System.exit(0);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void LoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LoginActionPerformed
        JOptionPane.showMessageDialog(null, "Esta seguro de cerrar la sesion?");
     login iniciar=new login();
    iniciar.setVisible(true);
    dispose();
    }//GEN-LAST:event_LoginActionPerformed

    private void btadmeventosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btadmeventosActionPerformed
        AdministraciondeEventos event=new AdministraciondeEventos();
        event.setVisible(true);
        dispose();
    }//GEN-LAST:event_btadmeventosActionPerformed

    private void btusuariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btusuariosActionPerformed
     administracionusuarios users=new administracionusuarios();
     users.setVisible(true);
     dispose();
    }//GEN-LAST:event_btusuariosActionPerformed

    private void btreportesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btreportesActionPerformed
        Reportes reportes=new Reportes();
        reportes.setVisible(true);
        dispose();
    }//GEN-LAST:event_btreportesActionPerformed

   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Login;
    private javax.swing.JButton btadmeventos;
    private javax.swing.JButton btreportes;
    private javax.swing.JButton btusuarios;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
