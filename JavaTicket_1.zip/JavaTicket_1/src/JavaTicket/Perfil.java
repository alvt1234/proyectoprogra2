
package JavaTicket;

public class Perfil extends javax.swing.JFrame {

    Controlardeportivo depor=new Controlardeportivo();
    Controlarreligioso religioso=new Controlarreligioso();
    Controlarmusical musical=new Controlarmusical();
    controlarusuarios usuarios=new controlarusuarios();
    UsuarioRegistrado aux=controlarusuarios.buscarUsuario(usuarios.getUsuariologueado());
    public Perfil() {
        initComponents();
        this.setLocationRelativeTo(null);
        if(aux==null){
            lbuser.setText("Admin");
            lbnombre.setText("Admin");
            txtcontraseña.setText("supersecreto");
            lbtipo.setText("Administrador");
            lbedad.setText("d");
        }else{
            lbuser.setText(usuarios.getUsuariologueado());
            lbnombre.setText(aux.getNombrecom());
            lbedad.setText(String.valueOf(aux.getEdad()));
            lbtipo.setText(aux.getTipousuario());
            txtcontraseña.setText(aux.getContraseña());
           
        }
        buscar();
   
    }

 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btregresar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        areafondo = new javax.swing.JTextArea();
        jLabel12 = new javax.swing.JLabel();
        lbtipo = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        lbuser = new javax.swing.JLabel();
        txtcontraseña = new javax.swing.JPasswordField();
        mostrarcontra = new javax.swing.JCheckBox();
        jLabel6 = new javax.swing.JLabel();
        lbedad = new javax.swing.JLabel();
        lbnombre = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btregresar.setBorderPainted(false);
        btregresar.setContentAreaFilled(false);
        btregresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btregresarActionPerformed(evt);
            }
        });
        jPanel1.add(btregresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 480, 140, 50));

        areafondo.setColumns(20);
        areafondo.setRows(5);
        jScrollPane1.setViewportView(areafondo);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 150, 450, 250));

        jLabel12.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Tipo usuario:");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 350, 130, 30));

        lbtipo.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        lbtipo.setForeground(new java.awt.Color(255, 255, 255));
        lbtipo.setText("jLabel2");
        jPanel1.add(lbtipo, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 350, 180, 30));

        jLabel7.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Codigo");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 110, 80, 30));

        jLabel8.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Tipo:");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 110, 60, 30));

        jLabel9.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Titulo");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 110, 70, 30));

        jLabel10.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Fecha");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 110, 70, 30));

        jLabel11.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Monto");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 110, 70, 30));

        lbuser.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        lbuser.setForeground(new java.awt.Color(255, 255, 255));
        lbuser.setText("jLabel2");
        jPanel1.add(lbuser, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 30, 160, 30));

        txtcontraseña.setEditable(false);
        jPanel1.add(txtcontraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 220, 140, 30));

        mostrarcontra.setText("Mostrar");
        mostrarcontra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mostrarcontraActionPerformed(evt);
            }
        });
        jPanel1.add(mostrarcontra, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 260, 80, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Edad:");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 300, 140, 30));

        lbedad.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        lbedad.setForeground(new java.awt.Color(255, 255, 255));
        lbedad.setText("jLabel2");
        jPanel1.add(lbedad, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 300, 180, 30));

        lbnombre.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        lbnombre.setForeground(new java.awt.Color(255, 255, 255));
        lbnombre.setText("jLabel2");
        jPanel1.add(lbnombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 170, 110, 30));

        jLabel3.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("User:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 30, 60, 30));

        jLabel4.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Contraseña:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, 180, 30));

        jLabel5.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Nombre completo:");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, 200, 30));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/perfil.png"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 880, 550));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void mostrarcontraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mostrarcontraActionPerformed
      if(mostrarcontra.isSelected()){
            txtcontraseña.setEchoChar((char)0);
        }else{
             txtcontraseña.setEchoChar('*');
        }
    }//GEN-LAST:event_mostrarcontraActionPerformed

    private void buscar(){
        StringBuilder evets = new StringBuilder(); 
        for(Eventodeportivo evento: depor.getListadeportes()){
             String buscarevento=depor.eventosfuturos(evento);
             evets.append(buscarevento).append("\n"); 
            }
        for(Eventomusical evento: musical.getListamusical()){
         String buscarevento=musical.eventosfuturos(evento);
             evets.append(buscarevento).append("\n"); 
        }
        for(Eventoreligioso evento: religioso.getListareligioso()){
             String buscarevento=religioso.eventosfuturos(evento);
             evets.append(buscarevento).append("\n");   
        }
     if(usuarios.getUsuariologueado().equals(depor.getUsercreador()) || usuarios.getUsuariologueado().equals(musical.getUsercreador()) ||usuarios.getUsuariologueado().equals(religioso.getUsercreador()) ){
            areafondo.setText(evets.toString());
        }
    }
  
    private void btregresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btregresarActionPerformed
        Reportes reportes = new Reportes();
        reportes.setVisible(true);
        dispose();
    }//GEN-LAST:event_btregresarActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea areafondo;
    private javax.swing.JButton btregresar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbedad;
    private javax.swing.JLabel lbnombre;
    private javax.swing.JLabel lbtipo;
    private javax.swing.JLabel lbuser;
    private javax.swing.JCheckBox mostrarcontra;
    private javax.swing.JPasswordField txtcontraseña;
    // End of variables declaration//GEN-END:variables
}
