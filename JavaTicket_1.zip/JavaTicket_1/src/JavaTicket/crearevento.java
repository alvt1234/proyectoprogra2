
package JavaTicket;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

  public class crearevento extends javax.swing.JPanel {
  private String seleccion;
  private static String numero;

  panelmusica musica =new panelmusica();
  PanelDeportes panel=new PanelDeportes();
  CrearReligioso religioso=new CrearReligioso();
    public crearevento() {
         initComponents();

        cbevento.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                seleccion = (String) cbevento.getSelectedItem();
                if(seleccion == null || seleccion.equals("Evento")){
                JOptionPane.showMessageDialog(null, "Elija el tipo de evento");
                }else{
                    if(seleccion.equals("Deportivo")){
                         crearpaneles(panel);
                        panel.setVisible(true);
                        panel.random();
                    } if(seleccion.equals("Musical")){
                        panel.setVisible(false);
                        crearpaneles(musica);
                    } if(seleccion.equals("Religioso")){
                        crearpaneles(religioso);
                    }

            } 
            }
        });
        
            
    }
  

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        cbevento = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        lbpersonas = new javax.swing.JLabel();
        panelfondo = new javax.swing.JPanel();

        setPreferredSize(new java.awt.Dimension(750, 510));

        jPanel1.setBackground(new java.awt.Color(204, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        cbevento.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Evento", "Deportivo", "Musical", "Religioso" }));
        jPanel1.add(cbevento, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 10, 100, 30));

        jLabel2.setFont(new java.awt.Font("Segoe UI Historic", 1, 16)); // NOI18N
        jLabel2.setText("Tipo de Evento");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 130, 30));
        jPanel1.add(lbpersonas, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 40, 220, 30));

        panelfondo.setBackground(new java.awt.Color(204, 255, 255));
        panelfondo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel1.add(panelfondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 50, 750, 460));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents
      private void crearpaneles(JPanel pa){
        pa.setSize(750, 210);
        pa.setLocation(0, 0);
        panelfondo.removeAll();
        panelfondo.add(pa, new org.netbeans.lib.awtextra.AbsoluteConstraints(0,0,-1,-1));
        panelfondo.revalidate();
        panelfondo.repaint(); 
     }

      
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cbevento;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lbpersonas;
    private javax.swing.JPanel panelfondo;
    // End of variables declaration//GEN-END:variables
}
