
package JavaTicket;

import java.util.ArrayList;
import java.util.Date;

public class Controlarreligioso {
     static ArrayList<Eventoreligioso> listareligioso = new ArrayList<>();
    private static String usercreador;
    private static double indemnizacion ;
    private static int cantrealizados,montototal,montofuturo,cantfuturos,contarcancelados;
    static controlarusuarios control=new controlarusuarios();
     UsuarioRegistrado aux=controlarusuarios.buscarUsuario(control.getUsuariologueado());
     
     public static boolean agregar(Eventoreligioso evento){
         usercreador=control.getUsuariologueado();
         if (buscarcodigo(evento.getCodigo()) == null) {
            listareligioso.add(evento);
            return true; 
        }
        return false; 
       }

    public static void eliminarEvento(int codigo) {
        Eventoreligioso evento = buscarcodigo(codigo);
            if (evento != null ) {
                
            listareligioso.remove(evento);
        }
    }

   
    public static Eventoreligioso buscarcodigo(int codigo) {
        for (Eventoreligioso evento : listareligioso) {
            if (evento != null && evento.getCodigo() == codigo) {
                return evento;
            }
        }
        return null; 
    }

   public String eventosrealizados(Eventoreligioso evento){
    long eventTime = evento.getFecha().getTime();
    long currentTime = System.currentTimeMillis();
    long diffInDays = (eventTime - currentTime) / (24 * 60 * 60 * 1000);
    if (diffInDays < 0) {
    return ""+evento.getCodigo()+"\t"+evento.getTipoevento()+"\t"+evento.getTitulo()+"\t"+evento.getFecha()+"\t"+evento.getMonto();
    }
    return null;
  }
    public String realizados() {
    StringBuilder resultado = new StringBuilder();
    for (Eventoreligioso evento : listareligioso) {
        String events = eventosrealizados(evento);
        if (events != null) { 
            resultado.append(events).append("\n");
        }
    }
    
    return resultado.toString();
}
    public String eventosporfecha(Eventoreligioso evento){
     return ""+evento.getCodigo()+"\t"+evento.getTipoevento()+"\t"+evento.getTitulo()+"\t"+evento.getFecha()+"\t"+evento.getMonto();
      }
     
    public String eventoscance(Eventoreligioso evento){
     return ""+evento.getCodigo()+"\t"+evento.getTipoevento()+"\t"+evento.getTitulo()+"\t"+evento.getFecha()+"\t"+"0";
      }
    
     public String eventosPorFecha() {
    StringBuilder resultado = new StringBuilder();
    
    for (Eventoreligioso evento : listareligioso) {
        resultado.append(eventoscance(evento)).append("\n");
         return resultado.toString();
    }
    return null;   
   
}
    public String porfecha() {
    StringBuilder resultado = new StringBuilder();
    for (Eventoreligioso evento : listareligioso) {
        String events = eventosporfecha(evento);
        if (events != null) { 
            resultado.append(events).append("\n");
            return resultado.toString();
        }
    }
    return null;
}
    public String eventosfuturos(Eventoreligioso evento){
    long eventTime = evento.getFecha().getTime();
    long currentTime = System.currentTimeMillis();
    long diffInDays = (eventTime - currentTime) / (24 * 60 * 60 * 1000);
    if (diffInDays > 0) {
    return ""+evento.getCodigo()+"\t"+evento.getTipoevento()+"\t"+evento.getTitulo()+"\t"+evento.getFecha()+"\t"+evento.getMonto()+"\t"+evento.getCancelar();
    }
    return null;
  }
    public String futuros() {
    StringBuilder resultado = new StringBuilder();
    for (Eventoreligioso evento : listareligioso) {
        String events = eventosfuturos(evento);
        if (events != null) { 
            resultado.append(events).append("\n");
             return resultado.toString();
        }
    }
    return null;
}
public String events(int code){
       Eventoreligioso eventos=buscarcodigo(code);
       if(eventos.getCodigo()==code && eventos.getCancelar().equals("cancelado")){
       return eventosPorFecha();
       }
       return null;
   }
    public  String getUsercreador() {
        return usercreador;
    }

    public static void setUsercreador(String usercreador) {
        Controlarreligioso.usercreador = usercreador;
    }
    public int getCantrealizados() {
        return cantrealizados;
    }

    public void setCantrealizados(int cantrealizados) {
        this.cantrealizados = this.cantrealizados+cantrealizados;
    }

    public int getMontototal() {
        return montototal;
    }

    public void setMontototal(int montototal) {
        this.montototal = this.montototal+montototal;
    }
    public int getMontofuturo() {
        return montofuturo;
    }

    public void setMontofuturo(int montofuturo) {
        this.montofuturo = this.montofuturo+montofuturo;
    }

    public int getCantfuturos() {
        return cantfuturos;
    }

    public void setCantfuturos(int cantfuturos) {
       this.cantfuturos = this.cantfuturos+cantfuturos;
    }

    public ArrayList<Eventoreligioso> getListareligioso() {
        return listareligioso;
    }
    public int getContarcancelados() {
        return contarcancelados;
    }

    public  void setContarcancelados(int contarcancelados) {
        this.contarcancelados = this.contarcancelados+contarcancelados;
    }
    
}
