
package JavaTicket;

public enum Tipoevento {
   DEPORTES,
   MUSICALES,
   RELIGIOSOS;
}
