
package JavaTicket;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import javax.swing.JOptionPane;

/**
 *
 * @author villa
 */
public class CrearReligioso extends javax.swing.JPanel {

    private String numero;
  private String fecha,titulo,descripcion,code,rentaTexto,personas;
  private int codigo,cantpersonas;
  Tipoevento tipo=Tipoevento.RELIGIOSOS;
  Eventoreligioso religioso;
  private Date fechaSeleccionada,currentDate;
  long diff,diffInDays;
    Random random = new Random();
    Controlarreligioso religios=new Controlarreligioso();
  controlarusuarios control=new controlarusuarios();
    public CrearReligioso() {
        initComponents();
       
       random();
    }

    private void random(){
        int randomNumber = random.nextInt(9999 - 1000 + 1) + 1000;
        numero=String.valueOf(randomNumber);
        System.out.println("codigo religioso: "+numero);
        txtcodigo.setText(numero);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        txtcodigo = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txttituloevento = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtdescripcion = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        datafecha = new com.toedter.calendar.JDateChooser();
        jLabel3 = new javax.swing.JLabel();
        txtrenta = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txtcantpersonas = new javax.swing.JTextField();
        btaceptar = new javax.swing.JButton();

        setPreferredSize(new java.awt.Dimension(750, 410));

        jPanel1.setBackground(new java.awt.Color(204, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setFont(new java.awt.Font("Segoe UI Historic", 1, 16)); // NOI18N
        jLabel4.setText("Codigo: ");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 80, 30));
        jPanel1.add(txtcodigo, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 20, 110, 30));

        jLabel5.setFont(new java.awt.Font("Segoe UI Historic", 1, 16)); // NOI18N
        jLabel5.setText("Titulo del evento:");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, 150, 30));
        jPanel1.add(txttituloevento, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 70, 280, 30));

        jLabel6.setFont(new java.awt.Font("Segoe UI Historic", 1, 16)); // NOI18N
        jLabel6.setText("Descripcion:");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 110, 140, 30));

        txtdescripcion.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        jPanel1.add(txtdescripcion, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 110, 280, 40));

        jLabel7.setFont(new java.awt.Font("Segoe UI Historic", 1, 16)); // NOI18N
        jLabel7.setText("Fecha:");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 170, 90, 30));
        jPanel1.add(datafecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 170, 170, 30));

        jLabel3.setFont(new java.awt.Font("Segoe UI Historic", 1, 16)); // NOI18N
        jLabel3.setText("Monto de renta:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, 140, 30));
        jPanel1.add(txtrenta, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 220, 120, 30));

        jLabel9.setFont(new java.awt.Font("Segoe UI Historic", 1, 16)); // NOI18N
        jLabel9.setText("CantidadPersonas:");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 270, 160, 30));

        jLabel10.setText("Cantidad permitida: 30mil.");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 300, 270, 30));
        jPanel1.add(txtcantpersonas, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 270, 100, 30));

        btaceptar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btaceptar.setText("Aceptar");
        btaceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btaceptarActionPerformed(evt);
            }
        });
        jPanel1.add(btaceptar, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 360, 90, 40));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

     private void limpiarcasillas(){
    datafecha.setDate(null);
    txtdescripcion.setText("");
    txtcodigo.setText("");
    txtrenta.setText("");
    txttituloevento.setText("");
    txtcantpersonas.setText("");
    }
    
    private void obtenertexto(){

        titulo= txttituloevento.getText();
        descripcion=txtdescripcion.getText();
        code=txtcodigo.getText();
        personas=txtcantpersonas.getText();   
        codigo=Integer.parseInt(code);
        rentaTexto = txtrenta.getText();
    }
     private void agguser(){ 
        java.util.Date date= new java.util.Date();
        SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd");
        fecha=format.format(datafecha.getDate());
         obtenertexto();
        if (!rentaTexto.isEmpty()) {
        try {
        int monto = Integer.parseInt(rentaTexto);
        int totalmonto=monto+2000;
        cantpersonas=Integer.parseInt(personas);
        religioso=new Eventoreligioso(2000, 0, codigo, descripcion, titulo, fechaSeleccionada, String.valueOf(tipo), totalmonto, cantpersonas,"");
        if(cantpersonas>30000){
        JOptionPane.showMessageDialog(null, "No puede ingresar mas de 30 mil personas");
        txtcantpersonas.setText("");
        }else  if(Controlarreligioso.agregar(religioso)){
         System.out.println("monto despues del if"+monto);
        JOptionPane.showMessageDialog(null, "Evento creado con exito"); 
        religioso.setCancelar("");
        if(religios.eventosrealizados(religioso)!=null){
         religios.setCantrealizados(1);
         religios.setMontototal(totalmonto);
        }
        if(religios.eventosfuturos(religioso)!=null){
        religios.setCantfuturos(1);
        religios.setMontofuturo(totalmonto);
        }
        limpiarcasillas();
        random();
        }else
        JOptionPane.showMessageDialog(null, "Ya hay un evento con ese codigo");
        } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null, "Ingresar solo numeros");
        }
        } else {
            System.out.println("campo vacio");
        }
    
    } 
    private void btaceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btaceptarActionPerformed

        //java.util.Date date= new java.util.Date();
        if (datafecha.getDate() != null) {
    fechaSeleccionada = datafecha.getDate(); 
    currentDate = new Date();
    diff = fechaSeleccionada.getTime() - currentDate.getTime();
    diffInDays = diff / (24 * 60 * 60 * 1000);
        } else {
    JOptionPane.showMessageDialog(null, "Elija una fecha.");
  }
        obtenertexto();
        System.out.println("fecha: "+fecha);

        if(txtdescripcion.getText().isEmpty() || txttituloevento.getText().isEmpty() || txtrenta.getText().isEmpty() || txtcantpersonas.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Tiene que llenar todos los campos");
        }else{
            UsuarioRegistrado aux=controlarusuarios.buscarUsuario(control.getUsuariologueado());
            if(aux!=null){
                if (!rentaTexto.isEmpty() ) {
                    try {
                        int monto = Integer.parseInt(rentaTexto);
                        int totalmonto=monto+2000;
                        cantpersonas=Integer.parseInt(personas);
                        religioso=new Eventoreligioso(2000, 0, codigo, descripcion, titulo, fechaSeleccionada, String.valueOf(tipo), totalmonto, cantpersonas,"");
                         if(cantpersonas>30000){
                            JOptionPane.showMessageDialog(null, "No puede ingresar mas de 30 mil personas");
                            txtcantpersonas.setText("");
                        }else
                        if(Controlarreligioso.agregar(religioso)){
                            JOptionPane.showMessageDialog(null, "Evento creado con exito");
                            religioso.setCancelar("");
                           if(religios.eventosrealizados(religioso)!=null){
                             religios.setCantrealizados(1);
                             religios.setMontototal(totalmonto);
                           }
                           if(religios.eventosfuturos(religioso)!=null){
                               religios.setCantfuturos(1);
                               religios.setMontofuturo(totalmonto);
                           }
                            limpiarcasillas();
                            random();
                        }else
                        JOptionPane.showMessageDialog(null, "Ya hay un evento con ese codigo");
                    } catch (NumberFormatException e) {
                        JOptionPane.showMessageDialog(null, "Ingresar solo numeros");
                    }
                } else
                System.out.println("campo vacio");

            }else
            agguser();

        }
    }//GEN-LAST:event_btaceptarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btaceptar;
    private com.toedter.calendar.JDateChooser datafecha;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField txtcantpersonas;
    private javax.swing.JTextField txtcodigo;
    private javax.swing.JTextField txtdescripcion;
    private javax.swing.JTextField txtrenta;
    private javax.swing.JTextField txttituloevento;
    // End of variables declaration//GEN-END:variables
}
