
package JavaTicket;

import java.awt.Font;
import java.util.Date;

public class cancelados extends javax.swing.JFrame {

     long eventTime;
    Controlardeportivo control=new Controlardeportivo();
    PanelDeportes panel=new PanelDeportes();
    Controlarmusical musical=new Controlarmusical();
    Controlarreligioso reli=new Controlarreligioso();
   EliminarEvento eliminar=new EliminarEvento();
    public cancelados() {
        initComponents();
        this.setLocationRelativeTo(null);
        Font Arial = new Font("Arial", Font.BOLD, 18);
        areafondo.setFont(Arial);
        
       
          for(Eventodeportivo evento: control.getListadeportes()){
               areafondo.setText(control.events(evento.getCodigo())+"\n");
          }
          for(Eventomusical evento: musical.getListamusical()){
              areafondo.setText(musical.events(evento.getCodigo())+"\n");
          }
          for(Eventoreligioso evento: reli.getListareligioso()){
              areafondo.setText(reli.events(evento.getCodigo())+"\n");
          }
          lbderealizados.setText(String.valueOf(control.getContarcancelados()));
          lbmurealizado.setText(String.valueOf(musical.getContarcancelados()));
          lbreRealizado.setText(String.valueOf(reli.getContarcancelados()));
          lbmontoDe.setText(String.valueOf(control.getIndemnizacion()));
          lbmontoMu.setText(String.valueOf(musical.getIndemnizacion()));
    }    
            
        
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        areafondo = new javax.swing.JTextArea();
        jButton1 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        lbderealizados = new javax.swing.JLabel();
        lbmurealizado = new javax.swing.JLabel();
        lbreRealizado = new javax.swing.JLabel();
        lbmontoDe = new javax.swing.JLabel();
        lbmontoMu = new javax.swing.JLabel();
        lbmontoRe = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        areafondo.setColumns(20);
        areafondo.setRows(5);
        jScrollPane1.setViewportView(areafondo);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 130, 550, 190));

        jButton1.setBorderPainted(false);
        jButton1.setContentAreaFilled(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 480, 130, 40));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel2.setFont(new java.awt.Font("Segoe UI Historic", 1, 17)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(50, 48, 217));
        jLabel2.setText("Tipo Evento");

        jLabel3.setFont(new java.awt.Font("Segoe UI Historic", 1, 17)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(50, 48, 217));
        jLabel3.setText("Cancelados");

        jLabel4.setFont(new java.awt.Font("Segoe UI Historic", 1, 17)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(50, 48, 217));
        jLabel4.setText("Monto total.");

        jLabel5.setFont(new java.awt.Font("Segoe UI Historic", 1, 17)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(50, 48, 217));
        jLabel5.setText("Deportivo:");

        jLabel6.setFont(new java.awt.Font("Segoe UI Historic", 1, 17)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(50, 48, 217));
        jLabel6.setText("Religioso:");

        jLabel7.setFont(new java.awt.Font("Segoe UI Historic", 1, 17)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(50, 48, 217));
        jLabel7.setText("Musical:");

        lbderealizados.setFont(new java.awt.Font("Segoe UI Historic", 1, 17)); // NOI18N
        lbderealizados.setForeground(new java.awt.Color(50, 48, 217));
        lbderealizados.setText("0");

        lbmurealizado.setFont(new java.awt.Font("Segoe UI Historic", 1, 17)); // NOI18N
        lbmurealizado.setForeground(new java.awt.Color(50, 48, 217));
        lbmurealizado.setText("0");

        lbreRealizado.setFont(new java.awt.Font("Segoe UI Historic", 1, 17)); // NOI18N
        lbreRealizado.setForeground(new java.awt.Color(50, 48, 217));
        lbreRealizado.setText("0");

        lbmontoDe.setFont(new java.awt.Font("Segoe UI Historic", 1, 17)); // NOI18N
        lbmontoDe.setForeground(new java.awt.Color(50, 48, 217));
        lbmontoDe.setText("0");

        lbmontoMu.setFont(new java.awt.Font("Segoe UI Historic", 1, 17)); // NOI18N
        lbmontoMu.setForeground(new java.awt.Color(50, 48, 217));
        lbmontoMu.setText("0");

        lbmontoRe.setFont(new java.awt.Font("Segoe UI Historic", 1, 17)); // NOI18N
        lbmontoRe.setForeground(new java.awt.Color(50, 48, 217));
        lbmontoRe.setText("0");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jLabel6)
                    .addComponent(jLabel5)
                    .addComponent(jLabel7))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel4))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lbmurealizado, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lbreRealizado, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(lbmontoMu, javax.swing.GroupLayout.DEFAULT_SIZE, 95, Short.MAX_VALUE)
                            .addComponent(lbmontoRe, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(lbderealizados, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addComponent(lbmontoDe, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(3, 3, 3)))
                .addContainerGap(30, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel3)
                        .addComponent(jLabel4)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(lbmontoMu)
                        .addGap(12, 12, 12)
                        .addComponent(lbmontoRe))
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addComponent(jLabel5)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jLabel7)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jLabel6))
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(lbderealizados)
                                .addComponent(lbmontoDe))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(lbmurealizado)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(lbreRealizado))))
                .addContainerGap(26, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 350, 360, 170));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/cancelados.png"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 880, 550));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        Reportes reportes=new Reportes();
        reportes.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea areafondo;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbderealizados;
    private javax.swing.JLabel lbmontoDe;
    private javax.swing.JLabel lbmontoMu;
    private javax.swing.JLabel lbmontoRe;
    private javax.swing.JLabel lbmurealizado;
    private javax.swing.JLabel lbreRealizado;
    // End of variables declaration//GEN-END:variables
}
