
package JavaTicket;

import javax.swing.JOptionPane;

public class vereventos extends javax.swing.JPanel {

    Controlardeportivo control=new Controlardeportivo();
    public vereventos() {
        initComponents();
        nomostrar();
    }
    private void nomostrar(){
        lbdescrip.setVisible(false);
        lbfecha.setVisible(false);
        lbtitulo.setVisible(false);
        lbmonto.setVisible(false);
        lbtipo.setVisible(false);
        lbcantpersonas.setVisible(false);
        lbpersonas.setVisible(false);
    }
    private void mostrar(){
        lbdescrip.setVisible(true);
        lbfecha.setVisible(true);
        lbtitulo.setVisible(true);
        lbmonto.setVisible(true);
        lbtipo.setVisible(true);
        lbcantpersonas.setVisible(true);
        lbpersonas.setVisible(true);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtcodigo = new javax.swing.JTextField();
        btbuscar = new javax.swing.JButton();
        lbdescrip = new javax.swing.JLabel();
        lbtitulo = new javax.swing.JLabel();
        lbfecha = new javax.swing.JLabel();
        lbmonto = new javax.swing.JLabel();
        lbtitulo2 = new javax.swing.JLabel();
        lbdescrip2 = new javax.swing.JLabel();
        lbfecha2 = new javax.swing.JLabel();
        lbmonto2 = new javax.swing.JLabel();
        lbtipo = new javax.swing.JLabel();
        lbtipo2 = new javax.swing.JLabel();
        lbextra = new javax.swing.JLabel();
        lbextra_ = new javax.swing.JLabel();
        lbextra1 = new javax.swing.JLabel();
        lbextra2 = new javax.swing.JLabel();
        lbcantpersonas = new javax.swing.JLabel();
        lbpersonas = new javax.swing.JLabel();
        lbextra3 = new javax.swing.JLabel();
        lbextra4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        areanombres = new javax.swing.JTextArea();

        jPanel1.setBackground(new java.awt.Color(204, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Yu Gothic Medium", 1, 14)); // NOI18N
        jLabel1.setText("EVENTOS");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel2.setText("CODIGO DEL EVENTO:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, -1, -1));
        jPanel1.add(txtcodigo, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 60, 130, 30));

        btbuscar.setBackground(new java.awt.Color(255, 204, 204));
        btbuscar.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        btbuscar.setText("Buscar");
        btbuscar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btbuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btbuscarActionPerformed(evt);
            }
        });
        jPanel1.add(btbuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 40, 110, 40));

        lbdescrip.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        lbdescrip.setText("Descripcion:");
        jPanel1.add(lbdescrip, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 190, 110, 30));

        lbtitulo.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        lbtitulo.setText("Titulo:");
        jPanel1.add(lbtitulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 150, 110, 30));

        lbfecha.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        lbfecha.setText("Fecha:");
        jPanel1.add(lbfecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 230, 110, 30));

        lbmonto.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        lbmonto.setText("Monto:");
        jPanel1.add(lbmonto, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 270, 110, 30));

        lbtitulo2.setFont(new java.awt.Font("Segoe UI Historic", 0, 14)); // NOI18N
        jPanel1.add(lbtitulo2, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 150, 280, 30));

        lbdescrip2.setFont(new java.awt.Font("Segoe UI Historic", 0, 14)); // NOI18N
        jPanel1.add(lbdescrip2, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 190, 280, 30));

        lbfecha2.setFont(new java.awt.Font("Segoe UI Historic", 0, 14)); // NOI18N
        jPanel1.add(lbfecha2, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 230, 140, 30));

        lbmonto2.setFont(new java.awt.Font("Segoe UI Historic", 0, 14)); // NOI18N
        jPanel1.add(lbmonto2, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 270, 170, 30));

        lbtipo.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        lbtipo.setText("Tipo evento:");
        jPanel1.add(lbtipo, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 110, 110, 30));

        lbtipo2.setFont(new java.awt.Font("Segoe UI Historic", 0, 14)); // NOI18N
        jPanel1.add(lbtipo2, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 110, 280, 30));

        lbextra.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        jPanel1.add(lbextra, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 390, 110, 30));

        lbextra_.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        jPanel1.add(lbextra_, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 350, 110, 30));

        lbextra1.setFont(new java.awt.Font("Segoe UI Historic", 0, 14)); // NOI18N
        jPanel1.add(lbextra1, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 350, 140, 30));

        lbextra2.setFont(new java.awt.Font("Segoe UI Historic", 0, 14)); // NOI18N
        jPanel1.add(lbextra2, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 390, 170, 30));

        lbcantpersonas.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        lbcantpersonas.setText("Cantidad personas:");
        jPanel1.add(lbcantpersonas, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 310, 170, 30));

        lbpersonas.setFont(new java.awt.Font("Segoe UI Historic", 0, 14)); // NOI18N
        jPanel1.add(lbpersonas, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 310, 170, 30));

        lbextra3.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        jPanel1.add(lbextra3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 430, 110, 30));

        lbextra4.setFont(new java.awt.Font("Segoe UI Historic", 0, 14)); // NOI18N
        jPanel1.add(lbextra4, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 430, 170, 30));

        areanombres.setColumns(20);
        areanombres.setRows(5);
        jScrollPane1.setViewportView(areanombres);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 140, -1, 180));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 751, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 510, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btbuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btbuscarActionPerformed
        int code=Integer.parseInt(txtcodigo.getText());
        Eventodeportivo depo=Controlardeportivo.buscarcodigo(code);
        Eventomusical mus=Controlarmusical.buscarcodigo(code);
        Eventoreligioso reli=Controlarreligioso.buscarcodigo(code);
         
        if(depo!=null && depo.getCodigo()==code){
            mostrar();
          //Eventodeportivo event=Controlardeportivo.cancelado(code);
          lbdescrip2.setText(depo.getDescrip());
          lbtipo2.setText(depo.getTipoevento());
          lbtitulo2.setText(depo.getTitulo());
          lbpersonas.setText(String.valueOf(depo.getCantpersonas()));
          lbfecha2.setText(String.valueOf(depo.getFecha()));
          lbmonto2.setText(String.valueOf(depo.getMonto()));
          lbextra_.setText("Equipo 1:");
          lbextra1.setText(depo.getEquipo1());
          lbextra.setText("Equipo 2:");
          lbextra2.setText(depo.getEquipo2());
          lbextra3.setText("Deporte: ");
          lbextra4.setText(depo.getTipoDeporte());
          areanombres.setText(String.valueOf(control.getNombres()));
        }else if(mus!=null && mus.getCodigo()==code){
            mostrar();
          lbdescrip2.setText(mus.getDescrip());
          lbtipo2.setText(mus.getTipoevento());
          lbtitulo2.setText(mus.getTitulo());
          lbfecha2.setText(String.valueOf(mus.getFecha()));
          lbpersonas.setText(String.valueOf(mus.getCantpersonas()));
          lbmonto2.setText(String.valueOf(mus.getMonto()));
          lbextra_.setText("Musica:");
          lbextra1.setText(mus.getTipoMusica());
          lbextra.setText("Seguro Grama: ");
          lbextra2.setText(String.valueOf(mus.getSeguroGrama()));
        }else if(reli!=null && reli.getCodigo()==code){
            mostrar();
          lbdescrip2.setText(reli.getDescrip());
          lbtipo2.setText(reli.getTipoevento());
          lbtitulo2.setText(reli.getTitulo());
          lbpersonas.setText(String.valueOf(reli.getCantpersonas()));
          lbfecha2.setText(String.valueOf(reli.getFecha()));
          lbmonto2.setText(String.valueOf(reli.getMonto()));
          lbextra_.setText("Musica:");
          lbextra1.setText(String.valueOf(reli.getPersonasConvertidas()));
          lbextra.setText("Seguro Grama: ");
          lbextra2.setText("2000");
        }else
        JOptionPane.showMessageDialog(null, "Codigo inexistente");

    }//GEN-LAST:event_btbuscarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea areanombres;
    private javax.swing.JButton btbuscar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbcantpersonas;
    private javax.swing.JLabel lbdescrip;
    private javax.swing.JLabel lbdescrip2;
    private javax.swing.JLabel lbextra;
    private javax.swing.JLabel lbextra1;
    private javax.swing.JLabel lbextra2;
    private javax.swing.JLabel lbextra3;
    private javax.swing.JLabel lbextra4;
    private javax.swing.JLabel lbextra_;
    private javax.swing.JLabel lbfecha;
    private javax.swing.JLabel lbfecha2;
    private javax.swing.JLabel lbmonto;
    private javax.swing.JLabel lbmonto2;
    private javax.swing.JLabel lbpersonas;
    private javax.swing.JLabel lbtipo;
    private javax.swing.JLabel lbtipo2;
    private javax.swing.JLabel lbtitulo;
    private javax.swing.JLabel lbtitulo2;
    private javax.swing.JTextField txtcodigo;
    // End of variables declaration//GEN-END:variables
}
